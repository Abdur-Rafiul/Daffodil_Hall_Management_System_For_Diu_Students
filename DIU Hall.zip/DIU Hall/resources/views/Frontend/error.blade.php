@extends('Frontend.Layout.app')
@section('content')
<div class="container">

<img class="w-100" src="/Frontend\images\error1.jpg" alt="">
</div>
@endsection