


<div class="container bg-light p-5 mb-4" style="border:2px dotted green;">
    <h1 class="text-center">Payment</h1>
    <div class="row">
        <div class="col-md-4">
            <h5>Please Select Your ID</h5>
            <input class="w-100 p-3 mb-2" id="studentid" type="text" style="border:2px solid green;" placeholder="Enter Your University ID">
            <h5>Please Select This Month</h5>
            <select class="w-100 p-3" name="" id="date" style="border:2px solid green;" >
                <option value="">January</option>
                <option value="">February</option>
                <option value="">March</option>
                <option value="">April</option>
                <option value="">May</option>
                <option value="">June</option>
                <option value="">July</option>
                <option value="">Augest</option>
                <option value="">September</option>
                <option value="">October</option>
                <option value="">November</option>
                <option value="">December</option>
            </select>
        </div>
        <div class="col-md-8" >
            <div class="col-md-12 text-center mt-5 mb-3">
                <h6>If you want to live in Rahat Villa, you must pay the monthly rent from here</h6>
            </div>
            <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4"><i class="fa-solid fa-2x fa-cart-shopping"></i>
            <button style="border:2px solid red; font-size:20px;" class="ms-3 btn btnPayment text-primary"><a>Payment</a></button></div>
            <div class="col-md-4"></div>
            </div>
        </div>
    </div>
</div>
</div>


