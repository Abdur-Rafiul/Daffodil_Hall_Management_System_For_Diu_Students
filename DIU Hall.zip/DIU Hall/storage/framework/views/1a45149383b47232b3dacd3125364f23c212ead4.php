<hr style="opacity:1;height:50px;width:100%; background-color:#31b086">
<?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/horizontal.blade.php ENDPATH**/ ?>