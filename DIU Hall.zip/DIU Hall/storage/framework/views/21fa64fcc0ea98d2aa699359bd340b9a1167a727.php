<footer class=" text-center text-white bg-primary text-white mt-3 container-fluid">
  <!-- Grid container -->
  <div class="container-fluid p-4 pb-0">
    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Facebook -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #3b5998;"
        href="https://www.facebook.com/groups/395049424796165"
        role="button"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- Twitter -->
      <a

      ></a>



      <!-- Instagram -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #ac2bac;"
        href="https://www.instagram.com/robin57607/"
        role="button"
        ><i class="fab fa-instagram"></i
      ></a>

      <!-- Linkedin -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #0082ca;"
        href="https://www.linkedin.com/authwall?trk=gf&trkInfo=AQFlyjs07dLfIgAAAYKx4B0Y_AYQwXx-wuzu9xxGG8_TeGswCJeE33xM7OKghs5Iho_2Y2cxLZVd9ean9HSajTlhgw9vkc--QtEkswHmdOAcfa9U9WDcyi0a_TeI5-yWk4FrB9k=&original_referer=https://www.google.com/&sessionRedirect=https%3A%2F%2Fwww.linkedin.com%2Fpub%2Fdir%2FRafiul%2FIslam"
        role="button"
        ><i class="fab fa-linkedin-in"></i
      ></a>
      <!-- Github -->
      <a
        class="btn btn-primary btn-floating m-1"
        style="background-color: #333333;"
        href="https://github.com/Abdur-Rafiul"
        role="button"
        ><i class="fab fa-github"></i
      ></a>
    </section>
    <!-- Section: Social media -->
  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2022 Daffodil International University
    <a class="text-white" href="https://www.facebook.com/groups/395049424796165">DIU</a>
  </div>
  <!-- Copyright -->
</footer>
<?php /**PATH D:\Rabbil Laravel\Daffodil_Hall_Management_System_For_Diu_Students\DIU Hall\resources\views/Frontend/Footer.blade.php ENDPATH**/ ?>