<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row d-flex justify-content-center">
<div class="col-md-12 col-sm-12 col-lg-12 p-lg-5 p-sm-0 p-md-0">
<table id="studentDt" class="table table-primary table-striped table-sm table-bordered" cellspacing="0" width="100%">
<thead>
    <tr>
      <th class="th-sm">Photo</th>
	  <th class="th-sm">Name</th>
	  <th class="th-sm">University Name</th>
    </tr>
</thead>
  <tbody>


  <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr class="">

      <td><img style="height:100px; width:100px" src="<?php echo e(asset($student['student_img'])); ?>"/> </td>
	  <td class="mt-5"><?php echo e($student['student_name']); ?></td>
	  <td><?php echo e($student['student_university']); ?>

  <button class="ms-5"><a class="ml-3 text-center"
    href="/unit/<?php echo e($student['floor_name']); ?>/<?php echo e($student['unit_name']); ?>/<?php echo e($student['student_id']); ?>">Details</a></button>
  </td>



    </tr>





     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script type="text/javascript">

$(document).ready(function() {
    $('#studentDt').DataTable();
    $('.dataTables_length').addClass('bs-select');
});




</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/manyStudentTable.blade.php ENDPATH**/ ?>