<?php $__env->startSection('title','Contact'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Frontend.auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row d-flex justify-content-center">


            <div class="col-lg-5 col-md-12 col-sm-12 bg-light p-lg-5 mt-2">
                <div class="panel-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                      <h1 class="d-none stdID"><?php echo e($id); ?></h1>
                <img style="width: 120px; height: 120px; position: relative; left: 37%; border-radius: 50%; border: #0080ff 1px solid" src="http://127.0.0.1:8000/storage/<?php echo e($img); ?>" alt="img" />
                <form action="<?php echo e(route('change.custom')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group mb-3 mt-2">
                        <input type="text" placeholder="<?php echo e($id); ?>" id="id" class="form-control" name="id"
                               disabled>

                    </div>

                    <div class="form-group mb-3">
                        <input type="text" placeholder="Old Password" id="old" class="form-control" name="old"
                               required autofocus>
                        <?php if($errors->has('old')): ?>
                            <span class="text-danger"><?php echo e($errors->first('old')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <input type="text" placeholder="New Password" id="newPassword" class="form-control" name="new"
                               required autofocus>
                        <?php if($errors->has('new')): ?>
                            <span class="text-danger"><?php echo e($errors->first('new')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <input type="text" placeholder="Conform Password" id="conformPassword" class="form-control"
                               name="conf" required autofocus>
                        <?php if($errors->has('conf')): ?>
                            <span class="text-danger"><?php echo e($errors->first('conf')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <div class="checkbox">
                            
                        </div>
                    </div>
                    <div class="d-grid mx-auto">
                        <button type="submit" class="btn btn-primary btn-block">Submit</button>
                    </div>
                </form>

            </div>


        </div>
    </div>


    <div class="fixed-bottom">

    <?php echo $__env->make('Frontend.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

    <script type="text/javascript">

        let oldPassword = $('.oldPassword').val();
        let newPassword = $('.newPassword').val();
        let conformPassword = $('.conformPassword').val();
        let id = $('.stdID').html();


        $('.submit').click(function (){

            alert(oldPassword+newPassword+conformPassword);

            if(newPassword == conformPassword){

                axios.post('/changePasswordPost',
                    {
                        old: oldPassword,
                        new:newPassword,
                        id:id
                    }

                )
                    .then(function(response) {




                        if (response.data == 1) {

                            alert("Password Change Successfully Done !")

                        }

                        else {
                            alert("Password not Change . after try again !")
                        }


                    }).catch(function(error) {



                });
            }else{
                alert("Your Password does not match");
            }
        })

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layout.appSupported', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/auth/ChangePassword.blade.php ENDPATH**/ ?>