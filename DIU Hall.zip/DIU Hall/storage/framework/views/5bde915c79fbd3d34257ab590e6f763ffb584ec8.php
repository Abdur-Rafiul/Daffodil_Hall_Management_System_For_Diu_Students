
<?php $__env->startSection('content'); ?>
<div class="container">

<img class="w-100" src="/Frontend\images\error1.jpg" alt="">
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/error.blade.php ENDPATH**/ ?>