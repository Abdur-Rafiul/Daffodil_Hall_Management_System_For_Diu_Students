<?php $__env->startSection('title','Contact'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Frontend.auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row d-flex justify-content-center">


            <div class="col-lg-5 col-md-12 col-sm-12 bg-light p-lg-5 mt-2">
                      <h1 class="d-none stdID"><?php echo e($id); ?></h1>
                <img style="width: 120px; height: 120px; position: relative; left: 37%; border-radius: 50%; border: #0080ff 1px solid" src="http://127.0.0.1:8000/storage/<?php echo e($img); ?>" alt="img" />
                <div class="form-outline mt-3 disabled">
                    <input  id="form12" class="form-control studentId2 text-muted" disabled placeholder="<?php echo e($id); ?>"/>


                </div>
                <div class="form-outline mt-3">
                    <input type="text" id="form12" class="form-control oldPassword" />
                    <label class="form-label" for="form12">Enter Your Old Password</label>

                </div>
                <div class="form-outline mt-3">
                    <input type="text" id="form12" class="form-control newPassword" />
                    <label class="form-label" for="form12">Enter Your New Password</label>

                </div>

                <div class="form-outline mt-3">
                    <input type="text" id="form12" class="form-control conformPassword" />
                    <label class="form-label" for="form12">Enter Your Conform Password</label>

                </div>

                <div class="d-grid gap-3 mt-3">
                    <button class="btn btn-lg btn-primary p-3 submit">Submit</button>
                </div>



            </div>


        </div>
    </div>


    <div class="fixed-bottom">

    <?php echo $__env->make('Frontend.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>

    <script type="text/javascript">

        let oldPassword = $('.oldPassword').val();
        let newPassword = $('.newPassword').val();
        let conformPassword = $('.conformPassword').val();
        let id = $('.stdID').html();


        $('.submit').click(function (){

            alert(oldPassword+newPassword+conformPassword);

            if(newPassword == conformPassword){

                axios.post('/changePasswordPost',
                    {
                        old: oldPassword,
                        new:newPassword,
                        id:id
                    }

                )
                    .then(function(response) {




                        if (response.data == 1) {

                            alert("Password Change Successfully Done !")

                        }

                        else {
                            alert("Password not Change . after try again !")
                        }


                    }).catch(function(error) {



                });
            }else{
                alert("Your Password does not match");
            }
        })

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layout.appSupported', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/ChangePassword.blade.php ENDPATH**/ ?>