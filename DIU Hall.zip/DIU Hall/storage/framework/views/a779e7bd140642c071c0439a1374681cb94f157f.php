<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
    <div style="height: 100%!important;">
    <?php echo $__env->make('Frontend.auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="login-form" style="height: fit-content!important;">
    <div class="container-fluid mt-5">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-4 col-sm-12">
                <div class="card p-lg-5">
                    <h3 class="card-header text-center">Login</h3>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('login.custom')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <input type="text" placeholder="StudentID" id="StudentID" class="form-control" name="StudentID" required
                                    autofocus>
                                <?php if($errors->has('StudentID')): ?>
                                <span class="text-danger"><?php echo e($errors->first('StudentID')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <input type="password" placeholder="Password" id="password" class="form-control" name="password" required>
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember"> Remember Me
                                    </label>
                                </div>
                            </div>
                            <div class="d-grid mx-auto">
                                <a class="nav-link text-primary" href="<?php echo e(route('reset')); ?>">Forgot Password</a>

                                <button type="submit" class="btn btn-primary btn-block mt-2 mb-4">Signin</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
    <div class="mt-5 fixed-bottom">

        <?php echo $__env->make('Frontend.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layout.appSupported', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/auth/login.blade.php ENDPATH**/ ?>