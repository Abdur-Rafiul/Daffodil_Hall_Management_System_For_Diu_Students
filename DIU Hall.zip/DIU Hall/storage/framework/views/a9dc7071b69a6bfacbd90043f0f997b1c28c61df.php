<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/mdb.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/sidenav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('Frontend/css/datatables-select.min.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?>
    </title>


</head>

<body>




    <div class="row main">
        <div class="col-lg-3 col-md-12 col-sm-12 menuStyle"><?php echo $__env->make('Backend.Layout.Menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        <div class="col-md-12 scroll">
          <div class="row">
              <div class="col-md-3"></div>
              <div class="col-md-9"> <?php echo $__env->yieldContent('content'); ?></div>
          </div>


        </div>

    </div>




<script type="text/javascript" src="<?php echo e(asset('Frontend/js/mdb.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Frontend/js/jquery-3.5.1.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Frontend/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Frontend/js/jquery.slimscroll.js')); ?>">
<script type="text/javascript" src="<?php echo e(asset('Frontend/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Frontend/js/bootstrap.js')); ?>"></script>

<script src="<?php echo e(asset('Frontend/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/sidebarmenu.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/sticky-kit.min.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/custom.min-2.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/datatables-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('Frontend/js/axios.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>

</body>

</html>
<?php /**PATH D:\Rabbil Laravel\Daffodil_Hall_Management_System_For_Diu_Students\DIU Hall\resources\views/backend/Layout/app2.blade.php ENDPATH**/ ?>