
<?php $__env->startSection('content'); ?>

<div class="container mt-5 text-center">
    <div class="row">
   <h3 class="floorSet mt-5 mb-5"></h3>
    <?php $__currentLoopData = $floorName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floorName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card " >
                <img style="height:12rem;"  src="<?php echo e(asset($floorName['unit_img'])); ?>"  class="card-img-top img-fluid rounded-0" alt="Fissure in Sandstone"/>
                <div class="card--body">
                <div class="card-title  mt-2">
                
               <h3 class="floorName d-none"><?php echo e($floorName['floor_name']); ?></h3>
               <a href="/unit/<?php echo e($floorName['floor_name']); ?>/<?php echo e($floorName['unit_name']); ?>"  class="btn btn-primary btn-block"><h3 data-name="<?php echo e($floorName['unit_name']); ?>" class="unitName"><?php echo e($floorName['unit_name']); ?></h3></a>
                
                </div>
                
                
                </div>
              </div>
      

 
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>



<?php $__env->stopSection(); ?>        


<?php $__env->startSection('script'); ?>



<script type="text/javascript">

let floorName = $('.floorName').html();
 $('.floorSet').html(floorName);

//  $('.unitName').click(function(){
//   let unitName = $(this).data('name');
  
//   console.log(unitName);
//   //href="/unit/+floorName+/+unitName";
  
//   //window.location=href;
//   window.location = '/unit?floorName=' + floorName + '&unitName=' + unitName;

// })
         



</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/Unit.blade.php ENDPATH**/ ?>