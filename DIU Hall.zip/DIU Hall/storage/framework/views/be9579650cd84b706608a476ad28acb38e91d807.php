
<div class="container">
    <div class="row d-flex justify-content-center">

        <div class="col-md-12 col-lg-5 col-sm-12">
        <a class="application-btn btn btn-block btn-dark btn-lg p-2 text-lg mb-1 " href="<?php echo e(url('/StudentApplication')); ?>">Click Me For Your Seat</a>
        </div>

    </div>
</div>

<?php /**PATH D:\Rabbil Laravel\Daffodil_Hall_Management_System_For_Diu_Students\DIU Hall\resources\views/Frontend/StudentApplicationApplyBtn.blade.php ENDPATH**/ ?>