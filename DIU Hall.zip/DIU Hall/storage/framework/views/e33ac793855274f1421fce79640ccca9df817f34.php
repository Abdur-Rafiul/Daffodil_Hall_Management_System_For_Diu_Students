<div class="container mb-3">
    <div class="row d-flex justify-content-center">
        <div class="col-md-12 col-lg-5 col-sm-12 card mt-2" style="border:2px solid green">
            <p class="">
                <h4>You will find many facilities in our Daffodil Hall.</h4>
                <h5>Below are some of the benefits:</h5>
                <ol>
                    <li>Security system is very good.</li>
                    <li>Arrangements for eating in the canteen.</li>
                    <li>Mosque for praying.</li>
                    <li>Beautiful facilities for doing sports</li>
                    <li>High speed internet for each students</li>
                    <li>One Bed per Student shall be offered</li>
                    <li>Students have to pay BDT- 2500/- per month. But mode of payment will be semester wise.</li>
                </ol>

            </p>
        </div>
    </div>
</div>
<?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/neededPage.blade.php ENDPATH**/ ?>