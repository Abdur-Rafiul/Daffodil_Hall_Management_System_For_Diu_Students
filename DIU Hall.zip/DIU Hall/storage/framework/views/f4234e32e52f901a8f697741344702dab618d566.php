<?php $__env->startSection('title','Password Reset'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Frontend.auth.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Verify Your Email Address</div>
                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                        </div>
                    <?php endif; ?>


                        <a href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="fixed-bottom">

        <?php echo $__env->make('Frontend.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.Layout.appSupported', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rabbil Laravel\RahatVilla\resources\views/Frontend/auth/customauth.blade.php ENDPATH**/ ?>